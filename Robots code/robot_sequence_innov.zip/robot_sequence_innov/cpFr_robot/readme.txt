Ce code ne test que un deplacement simple,
le reste est en commentaire
Dans stepperGoTo, une partie de l'ancien code d'acceleration est en commentaire, c'est normal